<?php
// Find these details in your hosting Control Panel under MySQL Databases
$host = ""; // Replace with your actual MySQL hostname (rarely 'localhost' on free hosts)
$user = "";     // Your hosting username
$pass = ""; // Usually your hosting account/vPanel password
$dbname = ""; // The exact database name you created in Step 1

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>  die("Database Connection Failed: " . $conn->connect_error);
}
?>