<?php
$env = @parse_ini_file(__DIR__ . '/.env') ?: [];

$host = $env['DB_HOST'] ?? "";  // Your database hostname
$user = $env['DB_USER'] ?? "";  // Your database username
$pass = $env['DB_PASS'] ?? "";  // Your database password
$dbname = $env['DB_NAME'] ?? "";  // Your database name

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($host, $user, $pass, $dbname);
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Database Connection Failed. Please check your configuration.");
}
?>
