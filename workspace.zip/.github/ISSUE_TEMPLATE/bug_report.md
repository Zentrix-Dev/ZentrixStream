---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment (please complete the following information):**
 - OS: [e.g. Ubuntu 20.04]
 - PHP Version: [e.g. 8.2]
 - MySQL Version: [e.g. 8.0]
 - Browser: [e.g. chrome, safari]

**Additional context**
Add any other context about the problem here.

**Security Note**
If this is a security-related bug (e.g., SQL injection, XSS), please email the maintainers directly instead of opening a public issue.
